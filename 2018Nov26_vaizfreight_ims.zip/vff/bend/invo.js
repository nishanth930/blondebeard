var mongoose = require('mongoose');
var Schema = mongoose.Schema;
var InvoSchema = new Schema({

    shippingType:String,
    Country:String,
    City:String,
    State:String,
    Postal:String,
    depature:String,
    country:String,
    city:String,
    state:String,
    postal:String,
    arriaval:String,
    quantity:String,
    quantityunit:String,
    totalweight:String,
    weightunit:String,
    dimensions:String,
    dimensionsunit:String,
    stackable:Boolean,
    hazardous:Boolean,
    insurance:Boolean,
    incotermsunit:String,
    comment:String,
    taxes:String,
    amount:String,
    totalamount:String
});
module.exports = mongoose.model('Invoices', InvoSchema);