const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const cors = require('cors');
const passport = require('passport');
const mongoose = require('mongoose');
const config = require('./config/database');
const nodemailer = require('nodemailer');
const Quote = require('./quote');
const Puro=require('./purchaseorder');
const Invoices = require ('./invo');
const  router = express.Router();
var app = express();
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// Connect To Database
mongoose.connect(config.database);

// On Connection
mongoose.connection.on('connected', () => {
  console.log('Connected to database '+config.database);
});

// On Error
mongoose.connection.on('error', (err) => {
  console.log('Database error: '+err);
});

const users = require('./routes/users');

// Port Number
const port = 3000;

// CORS Middleware
app.use(cors());

// Set Static Folder
app.use(express.static(path.join(__dirname, 'public')));

// Body Parser Middleware
app.use(bodyParser.json());

app.use('/users', users);
// Passport Middleware
app.use(passport.initialize());
app.use(passport.session());

require('./config/passport')(passport);

app.use('/users', users);

// Index Route
app.get('/', (req, res) => {
  res.send('Invalid Endpoint');
});
router.route('/quotes').get(function (req, res) {
  Quote.find(function (err, quotes) {
      if (err) {
          res.send(err);
      }
      res.send(quotes);
  });
}); 

router.route('/quotes').get(function (req, res) {
  Puro.find(function (err,pos ) {
      if (err) {
          res.send(err);
      }
      res.send(pos);
  });
});
router.route('/quotes').get(function (req, res) {
  Invoices.find(function (err, invoices) {
      if (err) {
          res.send(err);
      }
      res.send(invoices);
  }); 
});
router.route('/quotes/:id').get(function (req, res) {
Quote.findById(req.params.id, function (err, quote) {
      if (err)
          res.send(err);
     else{
      res.json(quote);
     } 
  });
}); 
router.route('/quotes/:id').post(function (req, res) {
      Quote.findById(req.params.id, (err, quote) => {
          if (!quote)
              return next(new Error('Could not load document'));
          else {
              
              quote.email = req.body.email;
              quote.consignee = req.body.consignee;
              quote.shippingType = req.body.shippingType;
              quote.Country = req.body.Country;
              quote.City = req.body.City;
              quote.State = req.body.State;
              quote.Postal = req.body.Postal;
              quote.departure = req.body.departure;
              quote.country = req.body.country;
              quote.city = req.body.city;
              quote.state = req.body.state;
              quote.postal = req.body.postal;
              quote.arrival = req.body.arrival;
              quote.quantity = req.body.quantity;
              quote.quantityunit = req.body.quantityunit;
              quote.totalweight = req.body.totalweight;
              quote.weightunit = req.body.weightunit;
              quote.length = req.body.length;
              quote.width = req.body.width;
              quote.height = req.body.height;
              quote.units = req.body.units;
              quote.stackable = req.body.stackable;
              quote.hazardous = req.body.hazardous;
              quote.insurance = req.body.insurance;
              quote.incotermsunit = req.body.incotermsunit;
              quote.comment = req.body.comment;
              quote.amount = req.body.amount;
              quote.taxes = req.body.taxes;
              quote.taxamount = req.body.taxamount;
              quote.totalamount = req.body.totalamount;
              quote.status = req.body.status;
              email = ` email:${req.body.email}`;
              const output = `

  <h3>Quotation Details</h3>
  <ul>  
  <li>ShippingType: ${req.body.shippingType}</li>
    <li>Departure Type: ${req.body.departure}</li>
    <li>Arrival Type: ${req.body.arrival}</li>
    <li>Amount: ${req.body.amount}</li>
    <li>Tax %: ${req.body.taxes}</li>
    <li>Tax Amount: ${req.body.taxamount}</li>
    <li>Total Amount: ${req.body.totalamount}</li>
  </ul>
  <h3>Message</h3>
  <p>${req.body.state}</p>
`;

// create reusable transporter object using the default SMTP transport
let transporter = nodemailer.createTransport({
  host: 'smtp.gmail.com',
  port: 587,
  secure: false, // true for 465, false for other ports
  auth: {
      user: 'likithasubramanyam@gmail.com', // generated ethereal user
      pass: 'liki@12345'  // generated ethereal password
  },
  tls:{
    rejectUnauthorized:false
  }
});
console.log(email)
// setup email data with unicode symbols
let mailOptions = {
    from: '"Shreepa Logistics" <likithasubramanyam@gmail.com>', // sender address
    to: email, // list of receivers
    subject: 'Quotation Details', // Subject line
    text: 'Hello world?', // plain text body
    html: output // html body
            
};

// send mail with defined transport object
transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
        return console.log(error);
    }
    console.log('Message sent: %s', info.messageId);   
    console.log('Preview URL: %s', nodemailer.getTestMessageUrl(info));

    res.render('contact', {msg:'Email has been sent'});
}); 
              quote.save().then(quote => {
                  res.json('Update done');
              }).catch(err => {
                  res.status(400).send('Update failed');
              });
          }
      } );
  })
// Start Server
app.use('/', router);
app.listen(port, () => {
  console.log('Server started on port '+port);
});
