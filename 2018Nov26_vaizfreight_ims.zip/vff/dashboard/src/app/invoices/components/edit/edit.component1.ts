import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormBuilder, Validators, FormsModule} from '@angular/forms';


import { Injectable, ErrorHandler } from '@angular/core';
import { InvoiceService } from '../../services/invoice.service';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Quote } from '../../models/quotation';
import { NgForm, FormControl, ReactiveFormsModule } from '@angular/forms';



@Component({
  selector: 'app-edit',
  templateUrl: './edit.component1.html',
  styleUrls: ['./edit.component1.scss']
})
// tslint:disable-next-line:component-class-suffix
export class EditComponent1 implements OnInit {
  ioForm: FormGroup;
  id: String;
  private quote: Quote;

  constructor(
    private invoiceService: InvoiceService,
     private router: Router,
      private route: ActivatedRoute,
       private fb: FormBuilder,

       ) {

  }


  ngOnInit() {
    this.route.params.subscribe(params => {
      this.id = params.id;
      this.invoiceService.getQuotes(this.id).subscribe(res => {
        this.quote = res;
        this.ioForm.get('email').setValue(this.quote.email);
        this.ioForm.get('consignee').setValue(this.quote.consignee);
        this.ioForm.get('shippingType').setValue(this.quote.shippingType);
        this.ioForm.get('Country').setValue(this.quote.Country);
        this.ioForm.get('City').setValue(this.quote.City);
        this.ioForm.get('State').setValue(this.quote.State);
        this.ioForm.get('Postal').setValue(this.quote.Postal);
        this.ioForm.get('departure').setValue(this.quote.departure);
        this.ioForm.get('country').setValue(this.quote.country);
        this.ioForm.get('city').setValue(this.quote.city);
        this.ioForm.get('state').setValue(this.quote.state);
        this.ioForm.get('postal').setValue(this.quote.postal);
        this.ioForm.get('arrival').setValue(this.quote.arrival);
        this.ioForm.get('quantity').setValue(this.quote.quantity);
        this.ioForm.get('quantityunit').setValue(this.quote.quantityunit);
        this.ioForm.get('totalweight').setValue(this.quote.totalweight);
        this.ioForm.get('weightunit').setValue(this.quote.weightunit);
        this.ioForm.get('length').setValue(this.quote.length);
        this.ioForm.get('width').setValue(this.quote.width);
        this.ioForm.get('height').setValue(this.quote.height);
        this.ioForm.get('units').setValue(this.quote.units);
        this.ioForm.get('stackable').setValue(this.quote.stackable);
        this.ioForm.get('hazardous').setValue(this.quote.hazardous);
        this.ioForm.get('insurance').setValue(this.quote.insurance);
        this.ioForm.get('incotermsunit').setValue(this.quote.incotermsunit);
        this.ioForm.get('status').setValue(this.quote.status);
        this.ioForm.get('comment').setValue(this.quote.comment);
        this.ioForm.get('amount').setValue(this.quote.amount);
        this.ioForm.get('taxes').setValue(this.quote.taxes);
        this.ioForm.get('taxamount').setValue(this.quote.taxamount);
        this.ioForm.get('totalamount').setValue(this.quote.totalamount);

      });
    });
    this.createForm();
  }
  updateQuote(consignee, email, shippingType, Country, City, State, Postal, departure, country,
    city, state, postal, arrival, quantity, quantityunit, totalweight, weightunit,
    length, width, height, units, stackable, hazardous, insurance,
     incotermsunit, comment, status , amount, taxes, taxamount, totalamount  ) {
    this.invoiceService.updateQuote(this.id, email, consignee, shippingType,
       Country, City, State, Postal, departure, country, city, state, postal,
       arrival, quantity, quantityunit, totalweight, weightunit, length,
       width, height, units, stackable, hazardous, insurance, incotermsunit,
        comment, status, amount, taxes, taxamount, totalamount  ).subscribe(() => {
    this.router.navigate(['dashboard', 'invoices']);
    });
  }

  private createForm() {
    this.ioForm = this.fb.group({
      email: '',
      consignee: '',
      shippingType: '',
      Country: '',
      City: '',
      State: '',
      Postal: '',
      departure: '',
      country: '',
      city: '',
      state: '',
      postal: '',
      arrival: '',
      quantity: '',
      quantityunit: '',
      totalweight: '',
      weightunit: '',
      length: '',
      width: '',
      height: '',
      units: '',
      stackable: '',
      hazardous: '',
      insurance: '',
      incotermsunit: '',
      comment: '',
      status: '',
      amount: '',
      taxes: '',
      taxamount: '',
      totalamount: '',
   
    });
  }
  private setQuoteToForm() {
    this.route.params
    .subscribe(params => {
      const id = params['id'];
      if (!id) {
        return;
      }
        this.invoiceService.getQuotes(id)
        .subscribe(quote => {
        this.quote = quote;
        this.ioForm.patchValue(this.quote);
        });

      });

    }


  } 