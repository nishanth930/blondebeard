import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RegisterComponent } from './components/register/register.component';
import { LoginComponent } from './components/login/login.component';

import { AuthGuard } from './guards/auth.guard';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { EditComponent1 } from './invoices/components/edit/edit.component1';
import { EditComponent2 } from './purchaseorder/components/edit/edit.component';
import { EditComponent } from './quotations/components/edit/edit.component';
import { InvoiceListingComponent } from './invoices/components/invoice-listing/invoice-listing.component';
import { PurchaseorderListingComponent } from './purchaseorder/components/purchaseorder-listing/purchaseorder-listing.component';
import { QuotationsListingComponent } from './quotations/components/quotations-listing/quotations-listing.component';


const routes: Routes = [
  {path:'register', component:RegisterComponent},
  {path:'', component:LoginComponent},
  {path:'dashboard', component:DashboardComponent,canActivate:[AuthGuard],
  children: [
    
    {
      path: 'quotations',
      component: QuotationsListingComponent
    },
    {
      path: 'purchaseorder',
      component: PurchaseorderListingComponent
    },
    {
      path: 'invoices',
      component: InvoiceListingComponent
    },
    {
      path: 'quotations/:id',
      component: EditComponent
    },
    {
      path: 'purchaseorder/:id',
      component: EditComponent2
    },
    {
      path: 'invoices/:id',
      component: EditComponent1
    }
  ]},
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
