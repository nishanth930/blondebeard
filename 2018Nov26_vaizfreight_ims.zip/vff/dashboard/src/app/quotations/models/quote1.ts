export class Quote1 {
    constructor(
        public shippingType: string,
        public Country: string,
        public City: string,
        public State: string,
        public Postal: string,
        public departure: string,
        public country: string,
        public city: string,
        public state: string,
        public postal: string,
        public arrival: string,
        public quantity: string,
        public quantityunit: string,
        public totalweight: string,
        public weightunit: string,
        public dimensions: string,
        public dimensionsunit: string,
        public stackble: boolean,
        public hazardous: boolean,
        public insurance: boolean,
        public incotermsunit: string,
        public comment: string,
        public amount: string,
  
     ) {}
  } 