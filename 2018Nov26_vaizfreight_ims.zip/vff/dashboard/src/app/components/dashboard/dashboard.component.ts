import { Component, OnInit, Output, EventEmitter, NgZone } from '@angular/core';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  private mediaMatcher:MediaQueryList =
  matchMedia('(max-width : ${MAX_WIDTH_BREAKPOINT}px)')
  lists = [{
    name: 'Dashboard',
    url: 'dashboard'
  }]; 
  links = [{
    name:'Quotations',
    url: 'quotations'
    
  },
{
  name:'Purchase Order',
  url:'purchaseorder'
},
{
  name:'Invoices',
  url:'invoices'
}]

  mediaMatcherList: MediaQueryListEvent;
  constructor(zone: NgZone) {
    this.mediaMatcher.addListener ( (mql) => {
      zone.run(() => this.mediaMatcherList = mql)
    })
    
   }
   
  
   isScreenSmall(){
    return this.mediaMatcher.matches;
  }
  @Output()  toggleSidenav = new EventEmitter <void>();
  ngOnInit(): void {
  }
  
}
