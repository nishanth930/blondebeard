import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from './dashboard.component';
//import { MainContentComponent } from './components/main-content/main-content.component';
import { QuotationsListingComponent } from 'src/app/quotations/components/quotations-listing/quotations-listing.component';
import { InvoiceListingComponent } from 'src/app/invoices/components/invoice-listing/invoice-listing.component';
import { PurchaseorderListingComponent } from 'src/app/purchaseorder/components/purchaseorder-listing/purchaseorder-listing.component';
import { EditComponent } from 'src/app/quotations/components/edit/edit.component';
import { EditComponent1 } from 'src/app/invoices/components/edit/edit.component1';
import { EditComponent2 } from 'src/app/purchaseorder/components/edit/edit.component';

const routes: Routes = [
  {
    path : '',
    component : DashboardComponent,
    children: [
      {
        path: 'quotations',
        component: QuotationsListingComponent
      },
      {
        path: 'purchaseorder',
        component: PurchaseorderListingComponent
      },
      {
        path: 'invoices',
        component: InvoiceListingComponent
      },
      {
        path: 'quotations/:id',
        component: EditComponent
      },
      {
        path: 'purchaseorder/:id',
        component: EditComponent2
      },
      {
        path: 'invoices/:id',
        component: EditComponent1
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DashboardRoutingModule { }
