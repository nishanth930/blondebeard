module.exports = {
    database: 'mongodb://13.233.14.111:27017/VaizFreight',
    secret: 'yoursecret'
  }
  

  //13.233.14.111:27017/VaizFreight.quotes