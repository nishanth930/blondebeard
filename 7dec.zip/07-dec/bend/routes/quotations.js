const express = require('express');
const router = express.Router();
const passport = require('passport');
const jwt = require('jsonwebtoken');
const User = require('../models/user');
const config = require('../config/database');
const Quotation = require('../models/quotation')

router.get('/', (req, res) => {
    Quotation.find((err, docs) => {
            if (!err) { res.send(docs); }
            else { console.log('Error in Retriving Employees :' + JSON.stringify(err, undefined, 2)); }
        });
    });
    
    
    router.post('/', (req, res) => {
        var quotation = new Quotation({
            email : req.body.email,
              consignee : req.body.consignee,
              shippingType : req.body.shippingType,
              Country : req.body.Country,
              City : req.body.City,
              State : req.body.State,
              Postal : req.body.Postal,
              departure : req.body.departure,
              country : req.body.country,
              city : req.body.city,
              state : req.body.state,
              postal : req.body.postal,
              arrival : req.body.arrival,
              quantity : req.body.quantity,
              quantityunit : req.body.quantityunit,
              totalweight : req.body.totalweight,
              weightunit : req.body.weightunit,
              length : req.body.length,
              width : req.body.width,
              height : req.body.height,
              units : req.body.units,
              stackable : req.body.stackable,
              hazardous : req.body.hazardous,
              insurance : req.body.insurance,
              incotermsunit : req.body.incotermsunit,
              comment : req.body.comment,
              taxes : req.body.taxes,
              taxamount : req.body.taxamount,
              totalamount : req.body.totalamount,
              status : req.body.status,
              startdate: req.body.startdate,
              deliverydate: req.body.deliverydate,
              slno :  req.body.slno,
              commodity : req.body.commodity,
              description: req.body.description,
              unitprice: req.body.unitprice,
              totalprice: req.body.totalprice,
              objid: req.body.objid,
              tax: req.body.tax
        });
        quotation.save((err, doc) => {
            if (!err) { res.send(doc); }
            else { console.log('Error in Employee Save :' + JSON.stringify(err, undefined, 2)); }
        });
    });
    module.exports = router;