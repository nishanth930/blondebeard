const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const cors = require('cors');
const passport = require('passport');
const mongoose = require('mongoose');
const config = require('./config/database');
const nodemailer = require('nodemailer');
const Quote = require('./quote');
const Quotation = require('./models/quotation');
const Purchaseorder=require('./models/purchaseorder');
const Invoices = require ('./models/invo');
const  router = express.Router();
var app = express();
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// Connect To Database
mongoose.connect(config.database);

// On Connection
mongoose.connection.on('connected', () => {
  console.log('Connected to database '+config.database);
});

// On Error
mongoose.connection.on('error', (err) => {
  console.log('Database error: '+err);
});

const users = require('./routes/users');
const quotations = require('./routes/quotations')
const purchaseorders = require('./routes/purchaseorder')
const invoices =  require('./routes/invoice')
// Port Number
const port = 3000;

// CORS Middleware
app.use(cors());

// Set Static Folder
app.use(express.static(path.join(__dirname, 'public')));

// Body Parser Middleware
app.use(bodyParser.json());

app.use('/users', users);
app.use('/quotations', quotations);
app.use('/purchaseorders', purchaseorders);
app.use('/invoices', invoices)
// Passport Middleware
app.use(passport.initialize());
app.use(passport.session());

require('./config/passport')(passport);

app.use('/users', users);

// Index Route
app.get('/', (req, res) => {
  res.send('Invalid Endpoint');
});
router.route('/quotes').get(function (req, res) {
  Quote.find(function (err, quotes) {
      if (err) {
          res.send(err);
      }
      res.send(quotes);
  });
}); 

router.route('/quotations').get(function (req, res) {
    Quotation.find(function (err,pos ) {
      if (err) {
          res.send(err);
      }
      res.send(pos);
  });
});
router.route('/quotations/:id').get(function (req, res) {
    Quotation.findById(req.params.id, function (err, pos) {
          if (err)
              res.send(err);
         else{
          res.json(pos);
         } 
      });
    });
    
router.route('/purchaseorders').get(function (req, res) {
    Purchaseorder.find(function (err, invoices) {
      if (err) {
          res.send(err);
      }
      res.send(invoices);
  }); 
});

router.route('/purchaseorders/:id').get(function (req, res) {
    Purchaseorder.findById(req.params.id, function (err, invoices) {
          if (err)
              res.send(err);
         else{
          res.json(invoices);
         } 
      });
    });

router.route('/quotes/:id').get(function (req, res) {
Quote.findById(req.params.id, function (err, quote) {
      if (err)
          res.send(err);
     else{
      res.json(quote);
     } 
  });
});

router.route('/quotes/:id').delete(function (req, res) {
Quote.findByIdAndRemove(req.params.id, function (err, quote) {
      if (err)
          res.send(err);
     else{
      res.json();
     } 
  });
}); 
router.route('/invoices').get(function (req, res) {
    Invoices.find(function (err,invo ) {
      if (err) {
          res.send(err);
      }
      res.send(invo);
  });
});

router.route('/quotes/:id').post(function (req, res) {
      Quote.findById(req.params.id, (err, quote) => {
          if (!quote)
              return next(new Error('Could not load document'));
          else {
              quote.consignee = req.body.consignee;
              quote.email = req.body.email;
              quote.shippingType = req.body.shippingType;
              quote.Country = req.body.Country;
              quote.City = req.body.City;
              quote.State = req.body.State;
              quote.Postal = req.body.Postal;
              quote.departure = req.body.departure;
              quote.country = req.body.country;
              quote.city = req.body.city;
              quote.state = req.body.state;
              quote.postal = req.body.postal;
              quote.arrival = req.body.arrival;
              quote.quantity = req.body.quantity;
              quote.quantityunit = req.body.quantityunit;
              quote.totalweight = req.body.totalweight;
              quote.weightunit = req.body.weightunit;
              quote.length = req.body.length;
              quote.width = req.body.width;
              quote.height = req.body.height;
              quote.units = req.body.units;
              quote.stackable = req.body.stackable;
              quote.hazardous = req.body.hazardous;
              quote.insurance = req.body.insurance;
              quote.incotermsunit = req.body.incotermsunit;
              quote.startdate = req.body.startdate;
              quote.commodity = req.body.commodity;
              quote.description = req.body.description;
              quote.comment = req.body.comment;
              quote.totalprice = req.body.totalprice;
              quote.status = req.body.status;
              quote.deliverydate = req.body.deliverydate;
              quote.unitprice = req.body.unitprice;
              quote.subtotal = req.body.subtotal;              
              quote.totalamount = req.body.totalamount;
              quote.tax = req.body.tax;
              quote.objid = req.body.objid,

              
              email = ` email:${req.body.email}`;
              const output = `

  <h3>Quotation Details</h3>
  <ul>  
  <li>ShippingType: ${req.body.shippingType}</li>
    <li>Departure Type: ${req.body.departure}</li>
    <li>Arrival Type: ${req.body.arrival}</li>
    <li>Sub-Total: ${req.body.totalprice}</li>
    <li>Tax %: ${req.body.tax}</li>
    <li>Total Amount: ${req.body.totalamount}</li>
  </ul>
  <h3>Message</h3>
  <p>${req.body.state}</p>
`;

// create reusable transporter object using the default SMTP transport
let transporter = nodemailer.createTransport({
  host: 'smtp.gmail.com',
  port: 587,
  secure: false, // true for 465, false for other ports
  auth: {
      user: 'likithasubramanyam@gmail.com', // generated ethereal user
      pass: 'liki@12345'  // generated ethereal password
  },
  tls:{
    rejectUnauthorized:false
  }
});
console.log(email)
// setup email data with unicode symbols
let mailOptions = {
    from: '"Shreepa Logistics" <likithasubramanyam@gmail.com>', // sender address
    to: email, // list of receivers
    subject: 'Quotation Details', // Subject line
    text: 'Hello world?', // plain text body
    html: output // html body
            
};

// send mail with defined transport object
transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
        return console.log(error);
    }
    console.log('Message sent: %s', info.messageId);   
    console.log('Preview URL: %s', nodemailer.getTestMessageUrl(info));

    res.render('contact', {msg:'Email has been sent'});
}); 
              quote.save().then(quote => {
                  res.json('Update done');
              }).catch(err => {
                  res.status(400).send('Update failed');
              });
          }
      } );
  })
// Start Server



router.route('/quotations/:id').post(function (req, res) {
    Quotation.findById(req.params.id, (err, pos) => {
        if (!pos)
            return next(new Error('Could not load document'));
        else {
            
            pos.consignee = req.body.consignee;
            pos.email = req.body.email;
            pos.shippingType = req.body.shippingType;
            pos.Country = req.body.Country;
            pos.City = req.body.City;
            pos.State = req.body.State;
            pos.Postal = req.body.Postal;
            pos.departure = req.body.departure;
            pos.country = req.body.country;
            pos.city = req.body.city;
            pos.state = req.body.state;
            pos.postal = req.body.postal;
            pos.arrival = req.body.arrival;
            pos.quantity = req.body.quantity;
            pos.quantityunit = req.body.quantityunit;
            pos.totalweight = req.body.totalweight;
            pos.weightunit = req.body.weightunit;
            pos.length = req.body.length;
            pos.width = req.body.width;
            pos.height = req.body.height;
            pos.units = req.body.units;
            pos.stackable = req.body.stackable;
            pos.hazardous = req.body.hazardous;
            pos.insurance = req.body.insurance;
            pos.incotermsunit = req.body.incotermsunit;
            pos.startdate = req.body.startdate;
            pos.commodity = req.body.commodity;
            pos.description = req.body.description;
            pos.comment = req.body.comment;
            pos.totalprice = req.body.totalprice;
            pos.status = req.body.status;
            pos.deliverydate = req.body.deliverydate;
            pos.unitprice = req.body.unitprice;
            pos.subtotal = req.body.subtotal;              
            pos.totalamount = req.body.totalamount;
            pos.tax = req.body.tax;
            pos.objid = req.body.objid,
            email = ` email:${req.body.email}`;
            const output = `

<h3>Quotation Details</h3>
<ul>  
<li>ShippingType: ${req.body.shippingType}</li>
  <li>Departure Type: ${req.body.departure}</li>
  <li>Arrival Type: ${req.body.arrival}</li>
  <li>Sub-Total: ${req.body.totalprice}</li>
  <li>Tax %: ${req.body.tax}</li>
  <li>Total Amount: ${req.body.totalamount}</li>
</ul>
<h3>Message</h3>
<p>${req.body.state}</p>
`;

// create reusable transporter object using the default SMTP transport
let transporter = nodemailer.createTransport({
host: 'smtp.gmail.com',
port: 587,
secure: false, // true for 465, false for other ports
auth: {
    user: 'likithasubramanyam@gmail.com', // generated ethereal user
    pass: 'liki@12345'  // generated ethereal password
},
tls:{
  rejectUnauthorized:false
}
});
console.log(email)
// setup email data with unicode symbols
let mailOptions = {
  from: '"Shreepa Logistics" <likithasubramanyam@gmail.com>', // sender address
  to: email, // list of receivers
  subject: 'Purchase Order Details', // Subject line
  text: 'Hello world?', // plain text body
  html: output // html body
          
};

// send mail with defined transport object
transporter.sendMail(mailOptions, (error, info) => {
  if (error) {
      return console.log(error);
  }
  console.log('Message sent: %s', info.messageId);   
  console.log('Preview URL: %s', nodemailer.getTestMessageUrl(info));

  res.render('contact', {msg:'Email has been sent'});
}); 
pos.save().then(quote => {
                res.json('Update done');
            }).catch(err => {
                res.status(400).send('Update failed');
            });
        }
    } );
})


router.route('/purchaseorders/:id').post(function (req, res) {
    Purchaseorder.findById(req.params.id, (err, invoices) => {
        if (!invoices)
            return next(new Error('Could not load document'));
        else {
            
            invoices.consignee = req.body.consignee;
            invoices.email = req.body.email;
            invoices.shippingType = req.body.shippingType;
            invoices.Country = req.body.Country;
            invoices.City = req.body.City;
            invoices.State = req.body.State;
            invoices.Postal = req.body.Postal;
            invoices.departure = req.body.departure;
            invoices.country = req.body.country;
            invoices.city = req.body.city;
            invoices.state = req.body.state;
            invoices.postal = req.body.postal;
            invoices.arrival = req.body.arrival;
            invoices.quantity = req.body.quantity;
            invoices.quantityunit = req.body.quantityunit;
            invoices.totalweight = req.body.totalweight;
            invoices.weightunit = req.body.weightunit;
            invoices.length = req.body.length;
            invoices.width = req.body.width;
            invoices.height = req.body.height;
            invoices.units = req.body.units;
            invoices.stackable = req.body.stackable;
            invoices.hazardous = req.body.hazardous;
            invoices.insurance = req.body.insurance;
            invoices.incotermsunit = req.body.incotermsunit;
            invoices.startdate = req.body.startdate;
            invoices.commodity = req.body.commodity;
            invoices.description = req.body.description;
            invoices.comment = req.body.comment;
            invoices.totalprice = req.body.totalprice;
            invoices.status = req.body.status;
            invoices.deliverydate = req.body.deliverydate;
            invoices.unitprice = req.body.unitprice;
            invoices.subtotal = req.body.subtotal;              
            invoices.totalamount = req.body.totalamount;
            invoices.tax = req.body.tax;
            invoices.objid = req.body.objid,
            email = ` email:${req.body.email}`;
            const output = `

<h3>Quotation Details</h3>
<ul>  
<li>ShippingType: ${req.body.shippingType}</li>
  <li>Departure Type: ${req.body.departure}</li>
  <li>Arrival Type: ${req.body.arrival}</li>
  <li>Sub-Total: ${req.body.totalprice}</li>
  <li>Tax %: ${req.body.tax}</li>
  <li>Total Amount: ${req.body.totalamount}</li>
</ul>
<h3>Message</h3>
<p>${req.body.state}</p>
`;

// create reusable transporter object using the default SMTP transport
let transporter = nodemailer.createTransport({
host: 'smtp.gmail.com',
port: 587,
secure: false, // true for 465, false for other ports
auth: {
    user: 'likithasubramanyam@gmail.com', // generated ethereal user
    pass: 'liki@12345'  // generated ethereal password
},
tls:{
  rejectUnauthorized:false
}
});
console.log(email)
// setup email data with unicode symbols
let mailOptions = {
  from: '"Shreepa Logistics" <likithasubramanyam@gmail.com>', // sender address
  to: email, // list of receivers
  subject: 'Invoice Details', // Subject line
  text: 'Hello world?', // plain text body
  html: output // html body
          
};

// send mail with defined transport object
transporter.sendMail(mailOptions, (error, info) => {
  if (error) {
      return console.log(error);
  }
  console.log('Message sent: %s', info.messageId);   
  console.log('Preview URL: %s', nodemailer.getTestMessageUrl(info));

  res.render('contact', {msg:'Email has been sent'});
}); 
invoices.save().then(invoices => {
                res.json('Update done');
            }).catch(err => {
                res.status(400).send('Update failed');
            });
        }
    } );
})
    
app.use('/', router);
app.listen(port, () => {
  console.log('Server started on port '+port);
});
