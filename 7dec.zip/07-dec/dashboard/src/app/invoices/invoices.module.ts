import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { InvoiceListingComponent } from './components/invoice-listing/invoice-listing.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MaterialModule } from '../shared/material.module';
import { HttpClientModule } from '@angular/common/http';
import { InvoiceService } from './services/invoice.service';
import { BrowserModule } from '@angular/platform-browser';
import { EditComponent1 } from './components/edit/edit.component1';

import { MatFormFieldModule, MatInputModule } from '@angular/material';
@NgModule({

  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MaterialModule,
    HttpClientModule,
    MatFormFieldModule,
    MatInputModule

  ],
  declarations: [InvoiceListingComponent, EditComponent1],
  exports: [InvoiceListingComponent, EditComponent1],
  providers: [InvoiceService]
})
export class InvoicesModule { }
