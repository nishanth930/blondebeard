import { Component, OnInit } from '@angular/core';
import { InvoiceService } from '../../services/invoice.service';
import { Quote } from '../../models/quotation';
import { NgForm } from '@angular/forms';
import { Router} from '@angular/router';

@Component({
  selector: 'app-quotations-listing',
  templateUrl: './invoice-listing.component.html',
  styleUrls: ['./invoice-listing.component.scss']
})
export class InvoiceListingComponent implements OnInit {
  submitted: boolean;
  errorMsg = '';
  constructor(private invoiceService: InvoiceService, private router: Router) { }

  displayedColumns: string[] = [ 'email', 'consignee', 'shippingType', 'Country', 'City',
   'State', 'Postal', 'departure', 'country', 'city', 'state', 'postal', 'arrival', 'quantity',
    'quantityunit', 'totalweight', 'weightunit', 'length', 'width', 'height', 'units', 'stackable',
    'hazardous', 'insurance', 'incotermsunit', 'comment', 'tax' ,'status', 'totalamount', 'action' ];
  public dataSource: any = [];
  saveBtnHandler() {
    this.router.navigate(['dashboard', 'invoices', 'new']);
  }
  editBtnHandler(id) {
    this.router.navigate(['dashboard', 'invoices', id]);
  }
  ngOnInit() {
    this.invoiceService.getQuote().subscribe(
      data => { this.dataSource = data;
      console.log(data);
    },
    err => {
      console.error(err);
    }
    );
  }
}
