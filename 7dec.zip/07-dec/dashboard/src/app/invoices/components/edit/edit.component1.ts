import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormBuilder, Validators, FormsModule} from '@angular/forms';


import { Injectable, ErrorHandler } from '@angular/core';
import { InvoiceService } from '../../services/invoice.service';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Quote } from '../../models/quotation';
import { NgForm, FormControl, ReactiveFormsModule } from '@angular/forms';
import { Quote1 } from '../../models/quote1';



@Component({
  selector: 'app-edit',
  templateUrl: './edit.component1.html',
  styleUrls: ['./edit.component1.scss']
})
// tslint:disable-next-line:component-class-suffix
export class EditComponent1 implements OnInit {
  public row: any = [{}];
  quoteForm: FormGroup;
  id: String;
  submitted = false;
   errorMsg = '';
  ngForm: any;
  private quote: Quote;
  quotationModel =  new Quote1( '', '', '', '', '', '', '', '',
  '', '', '', '', '', '', '', '', '', '', '', '', '', '', false, false, false, '', '', '', '', '','','',  '', '', '', '', '', '');
  constructor(
    private invoiceService: InvoiceService,
     private router: Router,
      private route: ActivatedRoute,
       private fb: FormBuilder,

       ) {

  }
  ngOnInit() {
    this.route.params.subscribe(params => {
      this.id = params.id;
      this.invoiceService.getQuotes(this.id).subscribe(res => {
        this.quote = res;
        this.quoteForm.get('email').setValue(this.quote.email);
        this.quoteForm.get('consignee').setValue(this.quote.consignee);
        this.quoteForm.get('shippingType').setValue(this.quote.shippingType);
        this.quoteForm.get('Country').setValue(this.quote.Country);
        this.quoteForm.get('City').setValue(this.quote.City);
        this.quoteForm.get('State').setValue(this.quote.State);
        this.quoteForm.get('Postal').setValue(this.quote.Postal);
        this.quoteForm.get('departure').setValue(this.quote.departure);
        this.quoteForm.get('country').setValue(this.quote.country);
        this.quoteForm.get('city').setValue(this.quote.city);
        this.quoteForm.get('state').setValue(this.quote.state);
        this.quoteForm.get('postal').setValue(this.quote.postal);
        this.quoteForm.get('arrival').setValue(this.quote.arrival);
        this.quoteForm.get('quantity').setValue(this.quote.quantity);
        this.quoteForm.get('quantityunit').setValue(this.quote.quantityunit);
        this.quoteForm.get('totalweight').setValue(this.quote.totalweight);
        this.quoteForm.get('weightunit').setValue(this.quote.weightunit);
        this.quoteForm.get('length').setValue(this.quote.length);
        this.quoteForm.get('width').setValue(this.quote.width);
        this.quoteForm.get('height').setValue(this.quote.height);
        this.quoteForm.get('units').setValue(this.quote.units);
        this.quoteForm.get('stackable').setValue(this.quote.stackable);
        this.quoteForm.get('hazardous').setValue(this.quote.hazardous);
        this.quoteForm.get('insurance').setValue(this.quote.insurance);
        this.quoteForm.get('incotermsunit').setValue(this.quote.incotermsunit);
        this.quoteForm.get('commodity').setValue(this.quote.commodity);
        this.quoteForm.get('description').setValue(this.quote.description);
        this.quoteForm.get('comment').setValue(this.quote.comment);
        this.quoteForm.get('totalprice').setValue(this.quote.totalprice);
        this.quoteForm.get('status').setValue(this.quote.status="Invoices");
        this.quoteForm.get('deliverydate').setValue(this.quote.deliverydate);
        this.quoteForm.get('unitprice').setValue(this.quote.unitprice);
        this.quoteForm.get('subtotal').setValue(this.quote.subtotal);
        this.quoteForm.get('totalamount').setValue(this.quote.totalamount);
        this.quoteForm.get('tax').setValue(this.quote.tax);
        this.quoteForm.get('objid').setValue(this.quote.objid);
        this.quoteForm.get('slno').setValue(this.quote.slno); 
      });
    });
    this.createForm();
  }
  updateQuote( 
    consignee,
    email, 
    shippingType, 
    Country,
    City, 
    State, 
    Postal, 
    departure, 
    country,
    city, 
    state, 
    postal, 
    arrival, 
    quantity, 
    quantityunit, 
    totalweight, 
    weightunit,
    length, 
    width, 
    height, 
    units, 
    stackable, 
    hazardous, 
    insurance, 
    incotermsunit,
    startdate,
    commodity,
    description,
    comment, 
    totalprice, 
    status,
    deliverydate, 
    unitprice, 
    subtotal, 
    totalamount, 
    tax, 
    objid  
     ) {
    this.invoiceService.updateQuote(
      this.id, 
      consignee, 
      email, 
      shippingType, 
      Country,
      City, 
      State, 
      Postal, 
      departure, 
      country,
      city, 
      state, 
      postal, 
      arrival, 
      quantity, 
      quantityunit, 
      totalweight, 
      weightunit,
      length, 
      width, 
      height, 
      units, 
      stackable, 
      hazardous, 
      insurance, 
      incotermsunit,
      startdate,
      commodity,
      description,
      comment, 
      totalprice, 
      status,
      deliverydate, 
      unitprice, 
      subtotal, 
      totalamount, 
      tax, 
      objid  ) .subscribe(() => {
    this.router.navigate(['dashboard', 'invoices']);
    });
  }
  deleteQuote(){
    this.invoiceService.deleteQuote(this.id ).subscribe(() => {
      this.router.navigate(['dashboard', 'invoices']);
      });
  }
 
  
  private createForm() {
    this.quoteForm = this.fb.group({
      
      consignee: '',
      email: '',
      shippingType: '',
      Country: '',
      City: '',
      State: '',
      Postal: '',
      departure: '',
      country: '',
      city: '',
      state: '',
      postal: '',
      arrival: '',
      quantity: '',
      quantityunit: '',
      totalweight: '',
      weightunit: '',
      length: '',
      width: '',
      height: '',
      units: '',
      stackable: '',
      hazardous: '',
      insurance: '',
      incotermsunit: '',
      startdate: '',
      comment: '',
      totalprice: '',
      status: '',
      commodity: '',
      description: '',
      deliverydate: '',
      unitprice: '',
      subtotal: '',
      totalamount: '',
      tax: '',
      objid: '',
      slno: '',
    });
  
  }
  
    onSubmit() {

      this.submitted = true;
      this.invoiceService.enroll(this.quotationModel)
      .subscribe(
       response => console.log('Success!', response),
       error => this.errorMsg = error.statusText);
      
      }


  addRow() {
    this.row.push({});
  }
  deleteRow(i) {
    this.row.splice(i, 1);

  }
  getRowValue() {
    console.log(this.row);
  }
  }
