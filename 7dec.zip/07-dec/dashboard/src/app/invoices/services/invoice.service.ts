import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Quote } from '../models/quotation';

import { Identifiers } from '@angular/compiler';
import { catchError } from 'rxjs/operators';
import { throwError } from 'rxjs';
import { $ } from 'protractor';
import { Quote1 } from '../models/quote1';

@Injectable()
export class InvoiceService {

   base_url = 'http://localhost:3000/purchaseorders';
   
  constructor(private http: HttpClient) { }

  selectedEmployee: Quote1;

  readonly baseURL = 'http://localhost:3000/invoices/';


  postUser(user: Quote1) {
    return this.http.post(this.baseURL, user);
  }
  enroll (user: Quote1) {
    return this.http.post<any>(this.baseURL, user)
      .pipe(catchError(this.errorHandler));
  }

  errorHandler(error: HttpErrorResponse) {
    return throwError(error);
  }

  getQuote(): Observable<Quote[]> {
    return this.http.get<Quote[]> (`${this.base_url}`);
  }


  getQuotes(id): Observable<Quote> {
    return this.http.get<Quote>(`${this.base_url}/${id}`);
  }
  updateQuote(
    id, 
    consignee, 
    email, 
    shippingType, 
    Country,
    City, 
    State, 
    Postal, 
    departure, 
    country,
    city, 
    state, 
    postal, 
    arrival, 
    quantity, 
    quantityunit, 
    totalweight, 
    weightunit,
    length, 
    width, 
    height, 
    units, 
    stackable, 
    hazardous, 
    insurance, 
    incotermsunit,
    startdate,
    commodity,
    description,
    comment, 
    totalprice, 
    status,
    deliverydate, 
    unitprice, 
    subtotal, 
    totalamount, 
    tax, 
    objid) {
    const quote = {
           consignee: consignee,
           email: email , 
           shippingType: shippingType,
           Country: Country,
           City: City,
           State: State,
           Postal: Postal,
           departure: departure,
           country: country,
           city: city,
           state: state,
           postal: postal ,
           arrival: arrival, 
           quantity: quantity,
           quantityunit: quantityunit,
           totalweight: totalweight,
           weightunit: weightunit,
           length: length,
           width: width,
           height: height,
           units: units,
           stackable: stackable,
           hazardous: hazardous, 
           insurance: insurance, 
           incotermsunit: incotermsunit,
           startdate: startdate,
           commodity:commodity,
           description:description,
           comment: comment, 
           totalprice: totalprice, 
           status:status,
           deliverydate: deliverydate,
           unitprice: unitprice,
           subtotal: subtotal,
           totalamount: totalamount,
           tax: tax, 
           objid: objid,
           
    };
    return this.http.post(`${this.base_url}/${id}`, quote);
  } 

  deleteQuote(id) {
    return this.http.delete(`${this.base_url}/${id}`);

  }
}
