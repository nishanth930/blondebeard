import { Component, OnInit, Output, EventEmitter, NgZone } from '@angular/core';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  private mediaMatcher:MediaQueryList =
  matchMedia('(max-width : ${MAX_WIDTH_BREAKPOINT}px)')
  lists = [{
    name: 'Dashboard',
    url: 'dashboard'
  }]; 
  links = [{
    name:' RFQ ',
    url: 'quotations'
    
  },
{
  name:' Quotations ',
  url:'purchaseorder'
},
{
  name:'Purchase Order',
  url:'invoices'
},
{
  name:'Invoices',
  url:'invo'
}
]

  mediaMatcherList: MediaQueryListEvent;
  constructor(zone: NgZone) {
    this.mediaMatcher.addListener ( (mql) => {
      zone.run(() => this.mediaMatcherList = mql)
    })
    
   }
   
  
   isScreenSmall(){
    return this.mediaMatcher.matches;
  }
  @Output()  toggleSidenav = new EventEmitter <void>();
  ngOnInit(): void {
  }
  
}
