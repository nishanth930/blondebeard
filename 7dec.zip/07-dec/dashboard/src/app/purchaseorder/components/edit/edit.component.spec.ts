import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditComponent2 } from './edit.component';

describe('EditComponent', () => {
  let component: EditComponent2;
  let fixture: ComponentFixture<EditComponent2>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditComponent2 ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditComponent2);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
