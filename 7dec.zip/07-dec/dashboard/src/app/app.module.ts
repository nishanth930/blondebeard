import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { HttpModule } from '@angular/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MaterialModule } from './shared/material.module'
import { InvoiceService } from './invoices/services/invoice.service';
import { QuotationService } from './quotations/services/quotation.service';
import { PurchaseorderService } from './purchaseorder/services/purchaseorder.service'
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ValidateService } from './services/validate.service';
import { AuthGuard } from './guards/auth.guard';
import { AuthService } from './services/auth.service';
import { NgFlashMessagesModule } from 'ng-flash-messages';
import { NavbarComponent } from './components/navbar/navbar.component';
import { RegisterComponent } from './components/register/register.component';

import { LoginComponent } from './components/login/login.component';
import {RouterModule, Routes} from '@angular/router';
import { DashboardComponent } from './components/dashboard/dashboard.component';


import { CommonModule } from '@angular/common';

import { MatSidenavContainer, MatSidenavContent, MatSidenavModule, MatListModule, MatCardModule } from '@angular/material';
import { InvoicesModule } from 'src/app/invoices/invoices.module';
import { PurchaseorderModule } from 'src/app/purchaseorder/purchaseorder.module';
import { QuotationsModule } from 'src/app/quotations/quotation.module';
import { ToolbarComponent } from './components/dashboard/components/toolbar/toolbar.component';
import { DashboardRoutingModule } from './components/dashboard/dashboard-routing.module';
import { QuotationsListingComponent } from './quotations/components/quotations-listing/quotations-listing.component';
import { PurchaseorderListingComponent } from './purchaseorder/components/purchaseorder-listing/purchaseorder-listing.component';
import { InvoiceListingComponent } from './invoices/components/invoice-listing/invoice-listing.component';
import { MainContentComponent } from './components/dashboard/components/main-content/main-content.component';
import { InvoListingComponent } from './invo/components/invo-listing/invo-listing.component';
import { InvoService } from './invo/services/invo.service';
import { InvoModule } from './invo/invo.module';


const routes: Routes = [
  {
    path: 'quotations',
    component: QuotationsListingComponent,
  },
  {
    path: 'purchaseorder',
    component: PurchaseorderListingComponent,
  },
  {
    path: 'invoices',
    component: InvoiceListingComponent,
  },
  {
    path: 'invo',
    component: InvoListingComponent,
  }
]

@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    LoginComponent,
    RegisterComponent,
    DashboardComponent,
    MainContentComponent,
     ToolbarComponent,
     InvoListingComponent
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MaterialModule,
    MatCardModule,
    FormsModule,
    ReactiveFormsModule,
    HttpModule,
    NgFlashMessagesModule,
    CommonModule,
    DashboardRoutingModule,
    InvoicesModule,
    PurchaseorderModule,
    QuotationsModule,
    InvoModule,
    
  ],
  exports: [
    MatSidenavContainer,
    MatSidenavContent,
    MatSidenavModule,
    MatListModule,
    MatCardModule
  ],
  providers: [InvoiceService,QuotationService,PurchaseorderService,InvoService,ValidateService,AuthService,AuthGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }
