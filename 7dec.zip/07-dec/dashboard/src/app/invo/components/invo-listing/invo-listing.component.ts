import { Component, OnInit } from '@angular/core';
import { Router} from '@angular/router';
import { InvoService } from '../../services/invo.service';

@Component({
  selector: 'app-invo-listing',
  templateUrl: './invo-listing.component.html',
  styleUrls: ['./invo-listing.component.scss']
})
export class InvoListingComponent implements OnInit {
  submitted: boolean;
  errorMsg = '';
  
  constructor(private router: Router, private invoService:InvoService) { }

  displayedColumns: string[] = [ 'email', 'consignee', 'shippingType', 'Country', 'City',
  'State', 'Postal', 'departure', 'country', 'city', 'state', 'postal', 'arrival', 'quantity',
   'quantityunit', 'totalweight', 'weightunit', 'length', 'width', 'height', 'units', 'stackable',
   'hazardous', 'insurance', 'incotermsunit', 'comment', 'tax' , 'totalamount', 'action' ];
 public dataSource: any = [];
 saveBtnHandler() {
   this.router.navigate(['dashboard', 'invo', 'new']);
 }
 editBtnHandler(id) {
   this.router.navigate(['dashboard', 'invo', id]);
 }
 ngOnInit() {
   this.invoService.getQuote().subscribe(
     data => { this.dataSource = data;
     console.log(data);
   },
   err => {
     console.error(err);
   }
   );
 }
}
