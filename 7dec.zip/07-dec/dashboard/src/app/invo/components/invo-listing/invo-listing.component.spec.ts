import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InvoListingComponent } from './invo-listing.component';

describe('InvoListingComponent', () => {
  let component: InvoListingComponent;
  let fixture: ComponentFixture<InvoListingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InvoListingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InvoListingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
