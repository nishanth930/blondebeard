export interface Issue{
    id:String;
    title:String;
    description:String;
    hours:String;
    unitprice:String;
    amount:String;
    action:String;
    
}